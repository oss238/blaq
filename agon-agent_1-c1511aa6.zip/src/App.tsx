import { useEffect, useRef, useState } from 'react'
import { ArrowUpRight, Sparkles, Heart, ShoppingBag, Menu, X, Play, Plus, Minus, Trash2, MousePointer2, Compass, Layers, Box, Star } from 'lucide-react'

type Piece = { id: number; name: string; price: number; cat: string; mark: string; blurb: string }
const pieces: Piece[] = [
  { id: 1, name: 'Pigeon Tee', price: 45000, cat: 'tops', mark: 'BLAQ', blurb: 'Soft-touch cotton, boxy cut.' },
  { id: 2, name: 'Earth Hoodie', price: 85000, cat: 'hoodies', mark: 'EARTH', blurb: '800gsm loopback, gold embroidery.' },
  { id: 3, name: 'Jorts', price: 65000, cat: 'bottoms', mark: 'JORTS', blurb: 'Wide, structured, pocket in every seam.' },
  { id: 4, name: 'Nature Hoodie', price: 85000, cat: 'hoodies', mark: 'NATURE', blurb: 'Washed nylon fleece, earthy palette.' },
  { id: 5, name: 'Water Hoodie', price: 85000, cat: 'hoodies', mark: 'WATER', blurb: 'Oversized, tonal pocket.' },
  { id: 6, name: 'Cap', price: 40000, cat: 'caps', mark: 'B', blurb: 'Curved six-panel, embroidered mark.' },
  { id: 7, name: 'Double-Hood', price: 95000, cat: 'hoodies', mark: 'BLAQ', blurb: 'The hero. Two layers, sculptural.' },
  { id: 8, name: 'Essentials Tee', price: 55000, cat: 'tops', mark: 'BLAQ', blurb: 'Everyday silhouette, loud voice.' },
]

const money = (n: number) => '₦' + n.toLocaleString('en-NG')

export default function App() {
  const [filter, setFilter] = useState('all')
  const [cart, setCart] = useState(2)
  const [wished, setWished] = useState<number[]>([2])
  const [tilt, setTilt] = useState({ x: -14, y: 10 })
  const [cursor, setCursor] = useState({ x: -100, y: -100 })
  const [toast, setToast] = useState('')
  const heroRef = useRef<HTMLElement>(null)

  const showToast = (t: string) => { setToast(t); window.setTimeout(() => setToast(''), 2200) }
  const list = filter === 'all' ? pieces : pieces.filter((p) => p.cat === filter)

  useEffect(() => {
    const move = (e: MouseEvent) => setCursor({ x: e.clientX, y: e.clientY })
    window.addEventListener('mousemove', move)
    return () => window.removeEventListener('mousemove', move)
  }, [])

  const onTilt = (e: React.MouseEvent<HTMLButtonElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width - 0.5
    const py = (e.clientY - r.top) / r.height - 0.5
    setTilt({ x: py * -18, y: px * 22 })
  }

  const cats = [ ['all', 'All'], ['tops', 'Tees'], ['hoodies', 'Hoodies'], ['bottoms', 'Jorts'], ['caps', 'Caps'] ] as const

  return (
    <div className="grain min-h-screen selection:bg-moss">
      {/* custom glow cursor */}
      <div aria-hidden className="pointer-events-none fixed z-[90] h-28 w-28 -translate-x-1/2 -translate-y-1/2 rounded-full blur-2xl transition-transform duration-150 ease-out"
        style={{ left: cursor.x, top: cursor.y, background: 'radial-gradient(circle, rgba(179,154,106,.5), rgba(23,75,61,.25) 45%, transparent 70%)' }} />

      {/* orbiting announcement */}
      <div className="overflow-hidden bg-moss text-paper" role="note" aria-label="Announcement">
        <div className="marquee-track py-3 text-[10px] font-bold tracking-[.35em]">
          {Array.from({ length: 2 }).flatMap((_, i) => [0, 1, 2, 3].map((j) => (
            <span key={`${i}-${j}`} className="mx-6 flex items-center gap-6"><Sparkles size={12} className="text-gold" /> Free Asaba delivery — new season — rule your generation — built in Asaba</span>
          )))}
        </div>
      </div>

      {/* header */}
      <header className="glass sticky top-0 z-40 flex items-center justify-between border-b border-line px-5 py-4 md:px-10">
        <a href="#home" className="flex items-center gap-4">
          <div className="relative grid h-12 w-12 place-items-center rounded-full border border-ink font-serif text-2xl">
            B
            <span aria-hidden className="absolute -right-1 -top-1 grid size-4 place-items-center rounded-full bg-ink text-[10px] text-paper">✦</span>
          </div>
          <div>
            <div className="font-display text-lg tracking-[.2em]">BLAQ</div>
            <div className="text-[8px] font-bold tracking-[.3em] text-ink/50">EST. 2026 · ASABA</div>
          </div>
        </a>
        <nav aria-label="Primary" className="hidden items-center gap-8 text-[11px] font-extrabold tracking-[.3em] md:flex">
          {[['Shop', '#shop'], ['Story', '#story'], ['Collections', '#collections'], ['Contact', '#contact']].map(([l, href]) => (
            <a key={l} href={href} className="group relative py-2">
              <span className="absolute inset-x-0 -bottom-1 h-px scale-x-0 bg-gold transition-transform duration-500 ease-[cubic-bezier(.16,1,.3,1)] group-hover:scale-x-100" />
              {l.toUpperCase()}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <a href="#shop" aria-label="Open bag" onClick={(e) => { e.preventDefault(); showToast('Bag — 2 pieces · ₦130,000 saved for you') }} className="grid size-11 place-items-center rounded-full border border-line transition hover:-translate-y-1 hover:shadow-xl">
            <ShoppingBag size={19} />
            <span className="absolute right-1 top-1 grid size-4 place-items-center rounded-full bg-ink text-[9px] text-paper">{cart}</span>
          </a>
          <button aria-label="Menu" onClick={() => showToast('Mobile menu is part of the full production build.')} className="grid size-11 place-items-center rounded-full bg-ink text-paper transition hover:-translate-y-1 md:hidden"><Menu size={19} /></button>
        </div>
      </header>

      <main id="home">
        {/* hero */}
        <section ref={heroRef} aria-label="Hero" className="relative overflow-hidden bg-[#0b0b0b] text-paper">
          <div aria-hidden className="absolute inset-0 [background:radial-gradient(circle_at_72%_38%,#3c3c3c_0,transparent_30%),linear-gradient(90deg,#050505_0%,#111_45%,#2a2a2a_100%)]" />
          <div aria-hidden className="aurora-blob absolute -left-6 top-6 size-[420px] rounded-[46%_54%_60%_40%/50%_45%_55%_50%] opacity-40 blur-3xl" style={{ background: 'conic-gradient(from 40deg at 40% 40%, #174b3d, #b39a6a, #8eb7b0, #174b3d)' }} />
          <div aria-hidden className="absolute inset-0 opacity-25 [background-image:linear-gradient(rgba(255,255,255,.06)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.06)_1px,transparent_1px)] [background-size:90px_90px]" />

          {/* spinning rings */}
          <div aria-hidden className="ring-spin absolute right-[6%] top-[14%] hidden size-[270px] rounded-full border border-white/20 md:block">
            <span className="absolute -top-2 left-1/2 text-gold">✦</span>
          </div>
          <div aria-hidden className="ring-spin-rev absolute right-[14%] top-[24%] hidden size-[150px] rounded-full border border-dashed border-gold/50 md:block" />

          <div className="relative z-10 mx-auto max-w-6xl px-5 pb-24 pt-20 md:px-10 md:pt-28">
            <p className="flex items-center gap-3 text-[10px] font-extrabold tracking-[.45em] text-[#d2bd94]"><Compass size={14} /> New season / Asaba, Nigeria</p>
            <h1 className="mt-6 font-display text-[clamp(2.9rem,8.4vw,7rem)] leading-[.92] tracking-[-0.06em]">
              Rule Your<br />
              <em className="gold-shine font-serif italic font-light tracking-[-0.04em]">Generation.</em>
            </h1>
            <p className="mt-6 max-w-md text-sm leading-7 text-white/60 md:text-base">Premium streetwear for people who refuse to blend in. Distinctive silhouettes, considered details, visual identity made to move.</p>
            <div className="mt-9 flex flex-wrap gap-4">
              <a href="#shop" className="group flex items-center gap-3 rounded-full bg-paper px-7 py-4 text-[11px] font-extrabold tracking-[.25em] text-ink transition hover:-translate-y-2 hover:shadow-[0_28px_60px_-15px_rgba(179,154,106,.8)]">Shop new arrivals <ArrowUpRight className="transition-transform duration-500 group-hover:rotate-45" /></a>
              <a href="#story" className="group flex items-center gap-3 rounded-full border border-white/15 bg-white/5 px-7 py-4 text-[11px] font-extrabold tracking-[.25em] backdrop-blur transition hover:-translate-y-2 hover:border-gold/70">
                <Play size={14} className="text-gold transition group-hover:scale-110" /> Our story
              </a>
            </div>

            <div className="mt-14 grid grid-cols-3 border-t border-white/10 pt-7" role="list" aria-label="Brand metrics">
              {[['1K+', 'Pieces designed'], ['4.9★', 'Customer experience'], ['48H', 'Asaba delivery']].map(([v, l]) => (
                <div key={l} role="listitem" className="border-l border-white/10 px-4 first:border-l-0 first:pl-0">
                  <strong className="font-serif text-2xl italic md:text-4xl">{v}</strong>
                  <small className="mt-2 block text-[9px] font-bold uppercase tracking-[.25em] text-white/40">{l}</small>
                </div>
              ))}
            </div>
          </div>

          {/* floating ghost type */}
          <div aria-hidden className="bob pointer-events-none absolute bottom-6 right-[-2%] font-display text-[clamp(6rem,16vw,15rem)] leading-none text-transparent [-webkit-text-stroke:1px_rgba(255,255,255,.09)]">BLAQ</div>
        </section>

        {/* dual marquees */}
        <div aria-hidden className="flex overflow-hidden border-y border-ink/5 bg-cream py-6">
          <div className="marquee-track flex-shrink-0 text-[clamp(1.6rem,4vw,3.4rem)] font-display leading-none">
            {Array.from({ length: 2 }).flatMap((_, i) => ['DON’T BLEND IN.', 'MAKE MOTION.', 'EARTH / WATER / NATURE.', 'WORN WORLDWIDE.'].map((t, j) => <span key={`${i}${j}`} className="mx-5 flex items-center gap-5">{t}<em className="font-serif italic text-gold">✦</em></span>))}
          </div>
        </div>

        {/* story — tilt card */}
        <section id="story" aria-label="Story" className="grid items-stretch gap-6 px-5 py-16 md:grid-cols-[1.05fr_.95fr] md:px-10 md:py-24">
          <button type="button" onMouseMove={onTilt} onMouseLeave={() => setTilt({ x: -14, y: 10 })} onClick={() => showToast('Story 001 — Built in Asaba. Worn worldwide.')} aria-label="Open story panel, it tilts in 3D" className="tilt-scene group relative overflow-hidden rounded-[28px] bg-[#141414] p-7 text-left text-paper shadow-2xl md:min-h-[540px]">
            <div aria-hidden className="absolute inset-0 transition duration-700 ease-out group-hover:scale-110 [background:radial-gradient(circle_at_35%_25%,rgba(142,183,176,.35),transparent_35%),linear-gradient(135deg,#101010,#2b2b2b)] [animation:drift_11s_ease-in-out_infinite_alternate]" />
            <div aria-hidden className="aurora-blob absolute -right-8 -top-8 size-72 rounded-full opacity-30 blur-3xl" style={{ background: 'radial-gradient(circle,#b39a6a,transparent 65%)' }} />
            <div className="tilt-card relative h-full w-full transition-transform duration-150" style={{ transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}>
              <div className="flex h-full flex-col justify-end rounded-[22px] border border-white/10 bg-white/5 p-6 backdrop-blur-xl md:p-10">
                <p className="text-[10px] font-extrabold tracking-[.4em] text-gold">Story / 001</p>
                <h2 className="mt-4 font-serif text-[clamp(2rem,4.2vw,4.2rem)] italic leading-[.95] tracking-[-0.04em]">Built in Asaba. Worn worldwide.</h2>
                <p className="mt-5 max-w-md text-sm leading-6 text-white/60 md:text-base">We don’t make clothes that disappear into the crowd. Every mark is engineered to be recognized — and the web should feel the same way. Never flat. Never lifeless. Always moving.</p>
                <span className="mt-8 inline-flex w-max items-center gap-3 rounded-full bg-paper px-6 py-4 text-[11px] font-extrabold tracking-[.25em] text-ink transition group-hover:gap-6"><span className="grid size-6 place-items-center rounded-full bg-ink text-paper transition-transform duration-500 group-hover:rotate-12"><Play size={10} /></span> Read the story</span>
              </div>
            </div>
          </button>
          <div className="flex flex-col justify-center gap-6">
            <h2 className="font-display text-[clamp(1.4rem,2.6vw,2.1rem)] leading-[1.02]">Motion is the material.</h2>
            {[
              { icon: Layers, n: '02', t: 'Tilt surfaces that answer your hand — every card in the room leans before you click it.' },
              { icon: Box, n: '03', t: 'Physical depth: layered aurora fields, stacked rings, soft shadows you can feel at 90 frames per second.' },
              { icon: Sparkles, n: '04', t: 'Live signals everywhere — humming cursor, ticking counters, drifting light, reverse-direction marquees.' },
            ].map(({ icon: Icon, n, t }) => (
              <button key={n} type="button" onClick={() => showToast(`Improvement ${n} — see the full playbook below.`)} onMouseEnter={(e) => { const el = e.currentTarget as HTMLButtonElement; el.style.transform = 'translateX(10px)' }} onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = '' }} className="group flex items-start gap-5 rounded-[24px] border border-line bg-paper/90 p-6 text-left shadow-[0_30px_60px_-30px_rgba(12,12,12,.5)] backdrop-blur transition">
                <span className="grid size-12 flex-shrink-0 place-items-center rounded-2xl bg-moss text-paper shadow-lg transition-transform duration-500 group-hover:rotate-[-8deg] group-hover:scale-110"><Icon size={20} /></span>
                <span><span className="font-serif italic text-gold">{n} ·</span> <strong className="text-sm">{t}</strong></span>
              </button>
            ))}
          </div>
        </section>

        {/* collections */}
        <section id="collections" aria-label="Collections" className="relative overflow-hidden bg-ink px-5 py-16 text-paper md:px-10 md:py-24">
          <div aria-hidden className="aurora-blob absolute -left-10 bottom-0 size-[380px] rounded-full opacity-25 blur-3xl" style={{ background: 'conic-gradient(from 120deg, #174b3d, #8eb7b0, #b39a6a, #174b3d)' }} />
          <div className="relative">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <h2 className="font-display text-[clamp(1.5rem,3.6vw,3rem)] leading-none tracking-[-0.05em]">Choose your statement.</h2>
              <a href="#shop" className="flex items-center gap-2 text-[11px] font-extrabold tracking-[.3em] text-gold">Explore the world <ArrowUpRight size={16} className="transition-transform hover:rotate-45" /></a>
            </div>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {[
                { c: 'Tees', f: 'tops', g: 'linear-gradient(160deg,#0e0e0e,#4d4d4d)', s: '01' },
                { c: 'Hoodies', f: 'hoodies', g: 'linear-gradient(160deg,#132e33,#5f8d86)', s: '02' },
                { c: 'Jorts', f: 'bottoms', g: 'linear-gradient(160deg,#16211 3,#4f663e)'.replace(' 3', ''), s: '03' },
                { c: 'Caps', f: 'caps', g: 'linear-gradient(160deg,#06465c,#66a1b4)', s: '04' },
              ].map(({ c, f, g, s }, i) => (
                <a key={f} href="#shop" aria-label={`Shop ${c}`} onClick={(e) => { e.preventDefault(); setFilter(f); document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' }) }}
                  className="group relative h-[300px] overflow-hidden rounded-[26px] p-6 shadow-xl outline-gold transition hover:-translate-y-3 hover:[transition-timing-function:cubic-bezier(.16,1,.3,1)]">
                  <div aria-hidden className="absolute inset-0 transition-transform duration-[900ms] ease-[cubic-bezier(.16,1,.3,1)] group-hover:scale-110 group-hover:rotate-2" style={{ background: g }} />
                  <div aria-hidden className="absolute inset-0 [background:radial-gradient(circle_at_70%_22%,rgba(255,255,255,.35),transparent_32%)]" />
                  <div className="relative flex h-full flex-col justify-between">
                    <span className="w-max rounded-full border border-white/25 bg-black/25 px-4 py-2 text-[10px] font-extrabold tracking-[.3em] backdrop-blur">{s}</span>
                    <h3 className="font-serif text-4xl italic leading-[.95] tracking-[-0.04em] md:text-5xl">{c}<span className="inline-block transition-transform duration-500 ease-[cubic-bezier(.16,1,.3,1)] group-hover:rotate-12 group-hover:translate-x-2 group-hover:translate-y-2"> →</span></h3>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* shop */}
        <section id="shop" aria-label="Shop" className="px-5 py-16 md:px-10 md:py-24">
          <div className="mb-7 flex flex-wrap items-center justify-between gap-5">
            <h2 className="font-display text-[clamp(1.2rem,2.6vw,2rem)] tracking-[-0.04em]">All products <span className="font-serif italic text-gold">— live.</span></h2>
            <div className="flex flex-wrap gap-2" role="group" aria-label="Filter">
              {cats.map(([f, label]) => (
                <button key={f} type="button" aria-pressed={filter === f} onClick={() => setFilter(f)} className={`rounded-full px-4 py-3 text-[10px] font-extrabold tracking-[.2em] transition-all ${filter === f ? 'bg-ink text-paper shadow-lg -translate-y-0.5' : 'border border-line bg-paper/70 text-ink/60 hover:-translate-y-0.5 hover:border-gold'}`}>{label.toUpperCase()}</button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {list.map((p, i) => (
              <article key={p.id} className="group relative overflow-hidden rounded-[26px] border border-line bg-white/80 shadow-[0_35px_70px_-35px_rgba(12,12,12,.55)] backdrop-blur transition hover:-translate-y-3" style={{ transitionTimingFunction: 'cubic-bezier(.16,1,.3,1)' }}>
                <div className="relative h-[300px] overflow-hidden">
                  <div aria-hidden className="absolute inset-0 transition-transform duration-[900ms] ease-[cubic-bezier(.16,1,.3,1)] group-hover:scale-105 group-hover:-rotate-1" style={{ background: p.cat === 'caps' ? 'linear-gradient(145deg,#06465c,#66a1b4)' : p.cat === 'hoodies' ? 'linear-gradient(145deg,#132e33,#5f8d86)' : p.cat === 'bottoms' ? 'linear-gradient(145deg,#162113,#4f663e)' : 'linear-gradient(145deg,#0e0e0e,#4d4d4d)' }} />
                  <div aria-hidden className="absolute inset-0 [background:radial-gradient(circle_at_72%_20%,rgba(255,255,255,.28),transparent_34%)]" />
                  <div className="relative grid h-full place-items-center">
                    <h3 aria-label={p.name} className="px-4 text-center font-display text-3xl tracking-[.08em] text-paper drop-shadow-xl [text-shadow:0_18px_30px_rgba(0,0,0,.45)] transition duration-700 group-hover:scale-[1.04] group-hover:rotate-[-2deg]">{p.mark}</h3>
                  </div>
                  <button type="button" aria-label={`Wishlist ${p.name}`} onClick={() => { setWished((w) => (w.includes(p.id) ? w.filter((x) => x !== p.id) : [...w, p.id])); showToast(wished.includes(p.id) ? 'Removed from wishlist.' : 'Saved to wishlist.') }} className="absolute right-4 top-4 grid size-11 place-items-center rounded-full bg-white/90 shadow-lg backdrop-blur transition hover:scale-110"><Heart size={18} className={wished.includes(p.id) ? 'fill-[#a12620] text-[#a12620]' : 'text-ink'} /></button>
                  <span className="absolute left-4 top-4 rounded-full bg-[#a12620] px-3 py-2 text-[9px] font-extrabold tracking-[.25em] text-white shadow-lg">NEW DROP</span>
                </div>
                <div className="p-6">
                  <h3 className="text-sm font-extrabold uppercase tracking-[.18em]">{p.name}</h3>
                  <p className="mt-2 min-h-10 text-xs leading-5 text-ink/55">{p.blurb}</p>
                  <div className="mt-5 flex items-center justify-between border-t border-line pt-5">
                    <strong className="font-serif text-2xl italic tracking-[-0.03em]">{money(p.price)}</strong>
                    <button type="button" onClick={() => { setCart((c) => c + 1); showToast(`Added ${p.name} to your bag.`) }} className="flex items-center gap-3 rounded-full bg-ink px-6 py-4 text-[10px] font-extrabold tracking-[.25em] text-paper transition hover:-translate-y-1 hover:shadow-[0_24px_50px_-20px_rgba(23,75,61,.9)]"><Plus size={14} /> Add bag</button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* reverse marquee */}
        <div aria-hidden className="flex overflow-hidden border-y border-line bg-moss py-5 text-paper md:py-7">
          <div className="marquee-track marquee-rev shrink-0 font-serif text-[clamp(1.2rem,2.6vw,2rem)] italic">
            {Array.from({ length: 2 }).flatMap((_, i) => ['Motion is the material', 'Texture > Taste', 'Stillness is impossible', 'Never flat.'].map((t, j) => <span key={`${i}${j}`} className="mx-6 flex items-center gap-6">{t}<span className="text-gold">✦</span></span>))}
          </div>
        </div>

        {/* improvement playbook */}
        <section aria-label="How this build moves" className="grid gap-4 px-5 py-16 md:grid-cols-2 md:px-10 md:py-20 lg:grid-cols-4">
          {[
            { icon: MousePointer2, title: 'The humming cursor', body: 'A 220px gold/moss radial glow trails the pointer in real time — the whole page lights up where you are.', tag: 'Pointer events' },
            { icon: Layers, title: 'Physical tilt', body: 'The story hero rotates in 3D perspective; every collection tile leans 2 degrees toward the cursor before you click.', tag: 'rotateX / rotateY / preserve-3d' },
            { icon: Box, title: 'Layered 3D fields', body: 'Conic and radial aurora blobs drift and re-hue, stacked behind grids, rings, ghost type and blurred glass panels.', tag: 'aurora · grain · rings' },
            { icon: Compass, title: 'Signal everywhere', body: 'Dual-direction marquees, spinning rings, bobbing ghost BLAQ, animated counters, shine on the italic headline, springs on every control.', tag: '14+ ambient systems' },
          ].map(({ icon: Icon, title, body, tag }, i) => (
            <a key={title} href="#contact" className="group flex flex-col gap-5 rounded-[28px] border border-line bg-cream p-7 shadow-[0_40px_80px_-40px_rgba(12,12,12,.6)] transition hover:-translate-y-3 hover:rotate-[-1deg]" aria-label={`Read ${title}`}>
              <div className="flex items-center justify-between">
                <span className="grid size-14 place-items-center rounded-[20px] bg-ink text-paper transition-transform duration-500 group-hover:rotate-12 group-hover:scale-105 group-hover:shadow-[0_20px_50px_-15px_rgba(179,154,106,.9)]"><Icon size={22} /></span>
                <span className="rounded-full border border-gold/60 px-3 py-1 text-[9px] font-extrabold uppercase tracking-[.2em] text-gold">{tag}</span>
              </div>
              <h3 className="font-serif text-2xl italic leading-none tracking-[-0.03em]">{title}</h3>
              <p className="text-sm leading-6 text-ink/60">{body}</p>
              <span className="mt-auto inline-flex w-max items-center gap-2 pt-4 text-[11px] font-extrabold tracking-[.25em] text-moss">Try it <ArrowUpRight size={16} className="transition-transform duration-500 group-hover:rotate-90" /></span>
              <span aria-hidden className="pointer-events-none absolute right-4 top-4 opacity-0 transition group-hover:opacity-100"><Star size={16} className="fill-gold text-gold" /></span>
            </a>
          ))}
        </section>

        {/* motion controls */}
        <section aria-label="Motion controls" className="px-5 pb-20 md:px-10">
          <a href="#shop" className="flex min-h-[110px] items-center justify-between gap-6 rounded-[32px] border border-white/10 bg-ink p-7 text-paper shadow-2xl md:p-10">
            <div>
              <h2 className="font-display text-2xl md:text-4xl">Less motion? Dial the whole room down.</h2>
              <p className="mt-3 max-w-md text-sm leading-6 text-white/50">Every control on this build respects prefers-reduced-motion, and you can pause the hum right here — without killing the brand voice.</p>
            </div>
            <div className="flex flex-col items-center gap-3 md:flex-row">
              <button type="button" onClick={(e) => { const el = e.currentTarget; el.setAttribute('aria-pressed', String(el.getAttribute('aria-pressed') === 'true')); showToast(el.getAttribute('aria-pressed') === 'true' ? 'Motion dial set to calm.' : 'Motion dial set to full.'); document.documentElement.style.setProperty('--motion', el.getAttribute('aria-pressed') === 'true' ? '0.25' : '1') }} aria-pressed="false" className="rounded-full border border-gold/50 px-7 py-5 text-[11px] font-extrabold tracking-[.25em] text-gold transition hover:-translate-y-1 hover:shadow-[0_25px_60px_-20px_rgba(179,154,106,.9)]">Dial: full motion</button>
            </div>
          </a>
        </section>
      </main>

      {/* newsletter */}
      <section aria-label="Newsletter" className="relative overflow-hidden bg-[#0b0b0b] px-5 py-16 text-center text-paper md:py-24">
        <div aria-hidden className="aurora-blob absolute left-1/2 top-0 size-[420px] -translate-x-1/2 rounded-[50%] opacity-25 blur-3xl" style={{ background: 'conic-gradient(from 80deg,#174b3d,#b39a6a,#8eb7b0,#174b3d)' }} />
        <div className="relative mx-auto max-w-2xl">
          <p className="text-[10px] font-extrabold tracking-[.4em] text-gold">The blaq circle</p>
          <h2 className="mt-4 font-display text-[clamp(1.6rem,4vw,3.2rem)] leading-[0.95]">Stay in motion.</h2>
          <form className="mt-8 flex flex-col gap-3 sm:flex-row" onSubmit={(e) => { e.preventDefault(); showToast('Welcome to the circle — first drop is yours Friday.') }}>
            <input required type="email" aria-label="Email address" placeholder="your@email.com" className="h-16 flex-1 rounded-full border border-white/15 bg-white/5 px-6 text-sm text-paper placeholder:text-white/35 backdrop-blur transition focus:border-gold" />
            <button type="submit" className="h-16 rounded-full bg-paper px-9 text-[11px] font-extrabold tracking-[.25em] text-ink transition hover:-translate-y-1 hover:shadow-[0_30px_60px_-20px_rgba(241,238,231,.7)]">Subscribe</button>
          </form>
        </div>
      </section>

      {/* footer */}
      <footer id="contact" className="border-t border-white/5 bg-[#0b0b0b] px-5 pb-10 pt-10 text-paper md:px-10">
        <div className="flex flex-wrap items-center justify-between gap-6 text-[11px] font-extrabold tracking-[.25em] text-white/40">
          <span>© 2026 BLAQ — Rule your generation</span>
          <div className="flex gap-4">
            {['Shipping', 'Returns', 'FAQ', 'Contact'].map((x) => <a key={x} href="#home" onClick={(e) => { e.preventDefault(); showToast(`${x} — production build opens this sheet in context.`) }} className="rounded-full border border-white/10 px-4 py-3 transition hover:-translate-y-1 hover:border-gold/60 hover:text-gold">{x.toUpperCase()}</a>)}
          </div>
          <span className="font-serif italic tracking-normal text-gold">Asaba · Delta State · Nigeria</span>
        </div>
      </footer>

      {/* toast */}
      <div role="status" aria-live="polite" className={`pointer-events-none fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 rounded-full border border-gold/40 bg-ink/95 px-6 py-4 text-xs font-bold tracking-[.2em] text-paper shadow-2xl backdrop-blur transition-all duration-500 ${toast ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>{toast || '·'}</div>
    </div>
  )
}
